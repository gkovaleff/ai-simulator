# Project Curator GPT Instructions

[Insert full instructions here]