# Project Customer GPT Instructions

[Insert full instructions here]