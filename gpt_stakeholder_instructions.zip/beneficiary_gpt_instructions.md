# Project Beneficiary GPT Instructions

[Insert full instructions here]