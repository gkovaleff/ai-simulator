# Combined GPT Instructions with Help Command

[Insert full combined content here]